var sysCities = {
    "fromcities": [
        {"name":"Medellín, CO", "id":"MDE"},
        {"name":"Cali, CO", "id":"CLO"},
        {"name":"Bogotá, CO", "id":"BGO"},
        {"name":"Barranquilla, CO", "id":"BAQ"}
    ],
                        
    "tocities": [
		{"name":"Aruba, AW", "id":"AUA"},
		{"name":"Panamá, PA", "id":"PTY"},
		{"name":"Lima, PE", "id":"LIM"},
		{"name":"Miami, US", "id":"MIA"},
		{"name":"Tampa, US", "id":"TPA"},
		{"name":"San José, CR", "id":"SJO"},
		{"name":"San Juan, PR", "id":"SJU"}
		
    ]
},
	copy_superior = "sdflskdfn",

 tarifas = {
 	[
 		"descripcion": "sdfsdfsdfsd",
	 	"precio": 1231312,
	 	"destino": "IATA",
	 	"origen": "IATA"
 	],
 	[
 		"descripcion": "sdfsdfsdfsd",
	 	"precio": 1231312,
	 	"destino": "PTY",
	 	"origen": "SJO"
 	],
 },

	departure_date = new Date(2017, 1 - 1, 25),
	return_date = new Date(2017, 3 - 1, 23);

